import type { Metadata } from "next";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FloatingRegister from "@/components/FloatingRegister";
import ScrollProgress from "@/components/ScrollProgress";

export const metadata:Metadata={
  metadataBase:new URL("https://iraqhomeexpo.com"),
  title:{default:"Iraq Home Expo 2027",template:"%s | Iraq Home Expo 2027"},
  description:"Iraq Home Expo 2027 — 12–15 May 2027 at Baghdad International Fair, Baghdad, Iraq.",
  openGraph:{title:"Iraq Home Expo 2027",description:"Meet the home, interiors and residential market in Baghdad.",type:"website",images:["/assets/hero-interior.webp"]},
  twitter:{card:"summary_large_image",title:"Iraq Home Expo 2027",description:"12–15 May 2027 · Baghdad International Fair"}
};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body><ScrollProgress/><Header/><main>{children}</main><FloatingRegister/><Footer/></body></html>}
