import Image from "next/image";
import Link from "next/link";

export default function PageHero({
  eyebrow,
  title,
  copy,
  image = "/assets/baghdad-fair-day.jpeg",
  imageAlt = "Iraq Home Expo exhibition experience",
  primary = "Register",
  primaryHref = "/register",
  compact = false,
}: {
  eyebrow: string;
  title: string;
  copy: string;
  image?: string;
  imageAlt?: string;
  primary?: string;
  primaryHref?: string;
  compact?: boolean;
}) {
  return (
    <section className={`modernPageHero ${compact ? "compact" : ""}`}>
      <div className="modernPageHeroCopy">
        <span className="eyebrow">{eyebrow}</span>
        <h1>{title}</h1>
        <p>{copy}</p>
        <Link className="button gold" href={primaryHref}>
          {primary}<span>↗</span>
        </Link>
      </div>
      <div className="modernPageHeroMedia">
        <Image src={image} fill priority alt={imageAlt} sizes="(max-width: 900px) 100vw, 56vw" />
        <div className="modernPageHeroMediaShade" aria-hidden="true" />
        <span className="modernPageHeroIndex" aria-hidden="true">Iraq Home Expo · 2027</span>
      </div>
    </section>
  );
}
