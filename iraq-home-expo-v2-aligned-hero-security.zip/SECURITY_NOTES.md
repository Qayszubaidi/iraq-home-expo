# Iraq Home Expo — Security Notes

This project keeps SMTP credentials server-side and exposes only public browser-safe configuration through `NEXT_PUBLIC_*` variables.

## Form hardening in this build

- JSON-only POST endpoint with a 64 KB request-size guard.
- Honeypot field retained for low-cost bot filtering.
- Per-instance IP rate limiting (6 submissions / 10 minutes).
- Optional production origin validation.
- Server-side field whitelist and maximum lengths.
- Required consent validation.
- Email/header input cleaning and HTML escaping before mail generation.
- SMTP connection/greeting/socket timeouts.
- Optional Cloudflare Turnstile validation; when `TURNSTILE_SECRET_KEY` is configured, a valid server-verified token is mandatory.
- Visitor/contact mail goes to `CONTACT_TO`; exhibitor mail goes to `SALES_TO`. Both may be comma-separated recipient lists.

## HTTP hardening

`next.config.ts` adds `nosniff`, SAMEORIGIN framing, strict referrer policy, restricted browser permissions, COOP, and a limited CSP for `frame-ancestors`, `object-src`, `base-uri`, and `form-action`.

## Source review performed

A static source review found no use of `eval`, `new Function`, `dangerouslySetInnerHTML`, `document.write`, `child_process`, shell execution, committed `.env`/private-key files, or hard-coded API/SMTP secrets. External runtime destinations are limited to the organizer/codeyea links, approved image hosts, YouTube, and Cloudflare Turnstile.

## Deployment checklist

1. Store SMTP and Turnstile secrets in the deployment platform's encrypted environment variables, never Git.
2. Configure `CONTACT_TO` and `SALES_TO` as comma-separated recipients.
3. Enable Turnstile before production launch.
4. Run `npm ci`, `npm run build`, and `npm audit` in CI/deployment using the committed lockfile.
5. Keep Next.js, React, Nodemailer, and the deployment runtime patched.
6. If traffic becomes substantial, move rate limiting from in-memory process state to a shared edge/Redis/WAF limiter.
