import Link from "next/link";
import { marketStats } from "@/data/site";
import { IconArrow } from "@/components/Icons";

export default function WhyIraq() {
  return (
    <>
      <section className="simplePageHead sectionShell whyHead">
        <span className="sectionEyebrow">Market opportunity</span>
        <h1>Why Iraq?</h1>
        <p>Growing urban demand, residential development and changing lifestyles are creating opportunity across Iraq&apos;s home and residential sectors.</p>
      </section>

      <section className="whyIntro sectionShell">
        <div><span className="sectionEyebrow">A market in transformation</span><h2>The home is at the heart of life in Iraq.</h2></div>
        <div><p>Home has strong cultural importance in Iraq, representing family, stability and identity. Alongside this, urbanization and residential development are increasing demand for modern products and solutions.</p><p>Iraq Home Expo creates a meeting point between this developing demand and international products, technologies and expertise.</p></div>
      </section>

      <section className="whyStats sectionShell">
        {marketStats.map(([n,l,d])=><article key={l}><strong>{n}</strong><h3>{l}</h3><p>{d}</p></article>)}
      </section>

      <section className="darkCtaBand">
        <div><span className="sectionEyebrow light">Enter · connect · grow</span><h2>Turn market potential into business opportunity.</h2></div>
        <Link className="btnGold" href="/exhibit">Exhibit with Us <IconArrow/></Link>
      </section>
    </>
  );
}
