import Image from "next/image";
import Link from "next/link";
import { event, marketStats, sectors } from "@/data/site";
import { IconCalendar, IconLocation, IconClock, IconArrow } from "@/components/Icons";

export default function Home() {
  return (
    <>
      <section className="homeHero">
        <Image src="/assets/hero-interior.webp" fill priority alt="Contemporary home interior" className="homeHeroImage" sizes="100vw"/>
        <div className="homeHeroShade"/>
        <div className="homeHeroPattern" aria-hidden="true"/>
        <div className="homeHeroInner">
          <div className="homeHeroCopy">
            <span className="kicker">Iraq Home Expo 2027</span>
            <h1>Iraq&apos;s home &amp;<br/>interiors market<br/><em>meets here.</em></h1>
            <p>The international exhibition for furniture, interiors, kitchens, home textiles, lighting, HVAC, appliances and smart-home solutions.</p>
            <div className="heroInfo">
              <div><IconCalendar size={22}/><span><strong>12–15 MAY 2027</strong></span></div>
              <div><IconLocation size={22}/><span><strong>Baghdad International Fair</strong><small>Baghdad, Iraq</small></span></div>
            </div>
            <div className="heroActions">
              <Link className="btnGold" href="/register#visitor">Visit the Expo <IconArrow/></Link>
              <Link className="btnOutline" href="/exhibit">Exhibit with Us <IconArrow/></Link>
            </div>
          </div>
        </div>
      </section>

      <section className="partnerStrip">
        <div className="partnerItem">
          <span>Under the Patronage of</span>
          <Image src="/assets/ministry-trade-logo.webp" width={90} height={90} alt="Republic of Iraq Ministry of Trade"/>
        </div>
        <div className="partnerDivider"/>
        <div className="partnerItem">
          <span>In Cooperation with</span>
          <Image src="/assets/expo-partner-logo.webp" width={90} height={90} alt="Exhibition partner"/>
        </div>
        <div className="partnerDivider"/>
        <div className="partnerItem wide">
          <span>Organized by</span>
          <Image src="/assets/success-steps-logo.webp" width={190} height={72} alt="Success Steps"/>
        </div>
      </section>

      <section className="homeIntro sectionShell">
        <div className="introCopy">
          <span className="sectionEyebrow">Welcome</span>
          <h2>Connecting global brands with Iraq&apos;s growing market.</h2>
          <p>Iraq Home Expo brings together international manufacturers, suppliers and industry professionals with buyers, distributors, retailers, designers, developers and decision-makers from across Iraq and the region.</p>
          <ul className="checkList">
            <li>Discover products &amp; new suppliers</li>
            <li>Meet buyers &amp; industry professionals</li>
            <li>Build partnerships &amp; grow your business</li>
          </ul>
          <Link className="btnTeal" href="/about">Discover More <IconArrow/></Link>
        </div>
        <div className="introArch">
          <div className="archFrame">
            <Image src="/assets/interiors.webp" fill alt="Interior design showcase" sizes="(max-width:800px) 88vw, 36vw"/>
          </div>
        </div>
        <div className="sectorPreview">
          <div className="sectorPreviewHead">
            <div><span className="sectionEyebrow">Exhibition sectors</span><h3>Explore a wide range of products and solutions.</h3></div>
            <Link href="/sectors">View all <IconArrow/></Link>
          </div>
          <div className="sectorMiniGrid">
            {sectors.slice(0,3).map((s) => (
              <Link href={`/sectors/${s.slug}`} key={s.slug} className="sectorMiniCard">
                <Image src={s.image} fill alt={s.title}/>
                <span className="sectorMiniShade"/>
                <strong>{s.title}</strong>
                <i>→</i>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="marketBand">
        <div className="marketBandInner">
          <span className="sectionEyebrow light">Why Iraq</span>
          <h2>A market full of opportunities</h2>
          <div className="marketStatRow">
            {marketStats.map(([value,label]) => (
              <div className="marketStat" key={label}>
                <span className="statGlyph">◇</span>
                <strong>{value}</strong>
                <small>{label}</small>
              </div>
            ))}
          </div>
          <Link className="btnGold compact" href="/why-iraq">Explore Why Iraq <IconArrow/></Link>
        </div>
      </section>

      <section className="visitFeature sectionShell">
        <div className="visitImage">
          <Image src="/assets/industry-professionals.webp" fill alt="Professional visitors at an exhibition"/>
        </div>
        <div className="visitCopy">
          <span className="sectionEyebrow">Why visit</span>
          <h2>Four days.<br/>Countless opportunities.</h2>
          <p>Whether you are sourcing new products, looking for suppliers, exploring solutions for projects or expanding your network, Iraq Home Expo is the place to be.</p>
          <div className="twoColList">
            <span>Discover new products</span>
            <span>Find new business partners</span>
            <span>Compare solutions</span>
            <span>Explore market opportunities</span>
            <span>Meet suppliers face-to-face</span>
            <span>Stay ahead of industry trends</span>
          </div>
          <Link className="btnTeal" href="/register#visitor">Register to Visit <IconArrow/></Link>
        </div>
      </section>

      <section className="exhibitFeature">
        <div className="exhibitCopy">
          <span className="sectionEyebrow light">Exhibit at Iraq Home Expo 2027</span>
          <h2>Showcase. Connect.<br/>Grow your business.</h2>
          <p>Present your products to a highly targeted audience of buyers and decision-makers and position your brand in one of the region&apos;s developing markets.</p>
          <div className="twoColList lightList">
            <span>Meet serious buyers</span><span>Launch new products</span>
            <span>Generate quality leads</span><span>Build long-term partnerships</span>
            <span>Increase brand visibility</span><span>Expand in the Iraqi market</span>
          </div>
          <div className="heroActions">
            <Link className="btnGold" href="/register#exhibitor">Book Your Stand <IconArrow/></Link>
            <Link className="btnOutline" href="/contact">Contact Sales <IconArrow/></Link>
          </div>
        </div>
        <div className="exhibitImage">
          <Image src="/assets/hero-interior.webp" fill alt="Modern home interior"/>
          <span className="exhibitPattern" aria-hidden="true"/>
        </div>
      </section>

      <section className="videoTeaser sectionShell">
        <div>
          <span className="sectionEyebrow">Organizer achievements</span>
          <h2>Experience the work behind the exhibition.</h2>
          <p>Explore previous Success Steps exhibitions and organizer achievements. A final project video can be embedded here when supplied.</p>
          <a className="textArrow" href="https://youtube.com/@successstepsco9702?si=BoYnb_s4IRmcqGvd" target="_blank" rel="noreferrer">View organizer videos <IconArrow/></a>
        </div>
        <a className="videoThumb" href="https://youtube.com/@successstepsco9702?si=BoYnb_s4IRmcqGvd" target="_blank" rel="noreferrer">
          <Image src="/assets/expo-event.webp" fill alt="Success Steps exhibition work"/>
          <span className="playRound">▶</span>
        </a>
      </section>
    </>
  );
}
