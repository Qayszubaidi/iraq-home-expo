import Image from "next/image";
import Link from "next/link";
import { event } from "@/data/site";
import { IconCalendar, IconClock, IconLocation, IconArrow } from "@/components/Icons";

export const metadata={title:"Visit Iraq Home Expo"};

export default function Visit() {
  return (
    <>
      <section className="simplePageHead sectionShell visitHead">
        <span className="sectionEyebrow">Visit Iraq Home Expo</span>
        <h1>Plan your visit.</h1>
        <p>Join thousands of buyers, architects, designers and industry professionals at Iraq&apos;s premier home &amp; interiors event.</p>
      </section>

      <section className="visitInfoCards sectionShell">
        <article><IconCalendar size={24}/><div><small>Date</small><strong>{event.dates}</strong></div></article>
        <article><IconLocation size={24}/><div><small>Venue</small><strong>{event.venue}</strong><span>{event.city}</span></div></article>
        <article><IconClock size={24}/><div><small>Opening hours</small><strong>{event.hours}</strong></div></article>
      </section>

      <section className="visitMain sectionShell">
        <div className="visitWhy">
          <span className="sectionEyebrow">Why visit?</span>
          <h2>Everything you need for a successful visit.</h2>
          <ul className="iconBulletList">
            {["Discover new products and innovations","Meet global brands and suppliers","Compare solutions and source smart","Network with industry professionals","Attend expert talks and live demos"].map(x=><li key={x}>{x}</li>)}
          </ul>
        </div>
        <div className="visitMainImage"><Image src="/assets/expo-event.webp" fill alt="Exhibition visitors"/></div>
      </section>

      <section className="visitorInfo sectionShell">
        <span className="sectionEyebrow">Visitor information</span>
        <div className="infoAccordion">
          <details open><summary>Registration</summary><p>Register online before the exhibition to receive your visitor confirmation and event updates.</p></details>
          <details><summary>Travel &amp; Stay</summary><p>Plan your travel and accommodation in Baghdad in advance. Further visitor guidance can be added as arrangements are confirmed.</p></details>
          <details><summary>Onsite Services</summary><p>Event services and visitor assistance will be available during the exhibition at Baghdad International Fair.</p></details>
        </div>
      </section>

      <section className="darkCtaBand">
        <div><span className="sectionEyebrow light">Ready to explore the future of home &amp; interiors?</span><h2>Register your visit today.</h2></div>
        <Link className="btnGold" href="/register#visitor">Register to Visit <IconArrow/></Link>
      </section>
    </>
  );
}
