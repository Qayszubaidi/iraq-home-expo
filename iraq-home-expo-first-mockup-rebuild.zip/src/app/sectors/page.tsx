import Image from "next/image";
import Link from "next/link";
import { sectors } from "@/data/site";
import { IconArrow } from "@/components/Icons";

export default function Sectors() {
  return (
    <>
      <section className="simplePageHead sectionShell">
        <span className="sectionEyebrow">Our exhibition sectors</span>
        <h1>Explore a wide range of<br/>products and solutions.</h1>
        <p>Discover the latest innovations, quality products and reliable solutions from leading global brands across eight focused industries.</p>
      </section>
      <section className="sectorCardGrid sectionShell">
        {sectors.map((s,i)=>(
          <Link className="sectorGridCard" href={`/sectors/${s.slug}`} key={s.slug}>
            <div className="sectorGridImage"><Image src={s.image} fill alt={s.title}/></div>
            <span className="sectorGridNum">{String(i+1).padStart(2,"0")}</span>
            <h2>{s.title}</h2>
            <p>{s.short}</p>
            <span className="cardArrow"><IconArrow/></span>
          </Link>
        ))}
      </section>
      <section className="darkCtaBand">
        <div><span className="sectionEyebrow light">Can&apos;t find your sector?</span><h2>Explore new opportunities with our team.</h2></div>
        <Link className="btnGold" href="/register#exhibitor">Book Your Stand <IconArrow/></Link>
      </section>
    </>
  );
}
