import Image from "next/image";
import Link from "next/link";
import { event } from "@/data/site";
import { IconArrow } from "@/components/Icons";

export const metadata={title:"Exhibit at Iraq Home Expo"};

export default function Exhibit() {
  return (
    <>
      <section className="exhibitLead sectionShell">
        <div>
          <span className="sectionEyebrow">Exhibit at Iraq Home Expo</span>
          <h1>Showcase. Connect.<br/>Grow your business.</h1>
          <p>Present your products to a highly targeted audience of buyers and decision-makers and position your brand in one of the region&apos;s developing markets.</p>
          <ul className="iconBulletList two">
            {["Meet serious buyers","Generate quality leads","Increase brand visibility","Launch new products","Build long-term partnerships","Expand in the Iraqi market"].map(x=><li key={x}>{x}</li>)}
          </ul>
        </div>
        <div className="exhibitLeadImage"><Image src="/assets/hero-interior.webp" fill alt="Interior products showcase"/></div>
      </section>

      <section className="participationSteps sectionShell">
        {[["01","Book your stand","Choose the right stand package for your business."],["02","Prepare & promote","Get the tools and support to maximize your presence."],["03","Connect & grow","Meet buyers and grow your business in Iraq."]].map(([n,h,p])=>(
          <article key={n}><span>{n}</span><h3>{h}</h3><p>{p}</p></article>
        ))}
      </section>

      <section className="marketBand smallBand">
        <div className="marketBandInner">
          <span className="sectionEyebrow light">Meet the Iraqi market in Baghdad</span>
          <h2>{event.dates} · {event.venue}</h2>
          <p>Use the exhibition as a focused route to buyers, distributors, retailers and project decision-makers.</p>
          <Link className="btnGold" href="/register#exhibitor">Register as an Exhibitor <IconArrow/></Link>
        </div>
      </section>
    </>
  );
}
