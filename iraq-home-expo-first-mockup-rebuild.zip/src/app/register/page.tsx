import { SmartForm } from "@/components/Forms";
import { event } from "@/data/site";

export default function Register() {
  return (
    <>
      <section className="simplePageHead sectionShell registerHead">
        <span className="sectionEyebrow">Register for Iraq Home Expo</span>
        <h1>Join us in Baghdad.</h1>
        <p>{event.dates} · {event.venue} · {event.city}</p>
      </section>

      <section className="registrationTabs sectionShell">
        <div className="registerChoiceBar">
          <a href="#visitor">Visitor Registration</a>
          <a href="#exhibitor">Exhibitor Registration</a>
        </div>

        <div id="visitor" className="registerFormLayout">
          <div className="registerFormMain">
            <span className="sectionEyebrow">Register as a visitor</span>
            <h2>Join Iraq Home Expo 2027.</h2>
            <p>Fill out the form below to register your visitor interest.</p>
            <SmartForm type="visitor"/>
          </div>
          <aside className="registerSupport">
            <h3>Why register?</h3>
            <ul><li>Fast visitor registration</li><li>Receive exhibition updates</li><li>Explore 8 industry sectors</li><li>Meet suppliers and brands</li></ul>
            <div><span>Need help?</span><a href="mailto:info@iraqhomeexpo.com">info@iraqhomeexpo.com</a><a href="tel:+9647824455860">07824455860</a></div>
          </aside>
        </div>

        <div id="exhibitor" className="registerFormLayout altRegister">
          <div className="registerFormMain">
            <span className="sectionEyebrow">Register as an exhibitor</span>
            <h2>Book your stand today.</h2>
            <p>Tell us about your company and participation requirements. Our sales team will contact you regarding the next steps.</p>
            <SmartForm type="exhibitor"/>
          </div>
          <aside className="registerSupport">
            <h3>Why exhibit?</h3>
            <ul><li>Access professional buyers</li><li>High brand visibility</li><li>Business growth opportunities</li><li>Build long-term partnerships</li></ul>
            <div><span>Need help?</span><a href="mailto:sales@iraqhomeexpo.com">sales@iraqhomeexpo.com</a><a href="tel:+9647702550297">07702550297</a></div>
          </aside>
        </div>
      </section>
    </>
  );
}
