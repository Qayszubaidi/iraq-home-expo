import Image from "next/image";
import Link from "next/link";
import { event } from "@/data/site";
import { IconArrow } from "@/components/Icons";

export const metadata = { title: "About Iraq Home Expo" };

export default function About() {
  return (
    <>
      <section className="innerSplitHero">
        <div className="innerSplitCopy">
          <span className="sectionEyebrow light">About Iraq Home Expo</span>
          <h1>Uniting global brands with Iraq&apos;s growing market.</h1>
          <p>Iraq Home Expo is the leading international exhibition for furniture, interiors, home textiles, lighting, HVAC, appliances and smart-home solutions.</p>
          <p>Our mission is to connect global suppliers with qualified buyers, industry professionals and decision-makers across Iraq and the region.</p>
        </div>
        <div className="innerSplitImage"><Image src="/assets/hero-interior.webp" fill priority alt="Modern interior"/></div>
      </section>

      <section className="valueCards sectionShell">
        {[["Global Connections","Bringing together international brands and local buyers."],["Business Growth","Creating opportunities that drive measurable growth."],["Industry Leadership","Setting the standard for quality and innovation in Iraq."]].map(([h,p],i)=>(
          <article key={h}><span>0{i+1}</span><h3>{h}</h3><p>{p}</p></article>
        ))}
      </section>

      <section className="aboutStory sectionShell">
        <div>
          <span className="sectionEyebrow">About the exhibition</span>
          <h2>Where products, people and opportunity meet.</h2>
        </div>
        <div>
          <p>Iraq Home Expo brings the complete home industry together under one roof. The exhibition creates a focused environment for product discovery, sourcing, distribution conversations and long-term business relationships.</p>
          <p>Across eight major sectors, professional visitors can compare solutions, meet suppliers and explore the products shaping modern residential environments.</p>
        </div>
      </section>

      <section className="darkCtaBand">
        <div><span className="sectionEyebrow light">12–15 May 2027 · Baghdad</span><h2>Be part of Iraq&apos;s home and interiors event.</h2></div>
        <div className="heroActions"><Link className="btnGold" href="/register#visitor">Register to Visit <IconArrow/></Link><Link className="btnOutline" href="/register#exhibitor">Exhibit with Us <IconArrow/></Link></div>
      </section>
    </>
  );
}
