import { SmartForm } from "@/components/Forms";

export default function Contact() {
  return (
    <section className="contactPage">
      <div className="contactPanel">
        <span className="sectionEyebrow light">Get in touch</span>
        <h1>We&apos;re here to help.</h1>
        <p>Have a question or need more information? Our team is happy to assist you.</p>
        <dl>
          <div><dt>Phone</dt><dd><a href="tel:+9647824455860">07824455860</a><a href="tel:+9647702550297">07702550297</a></dd></div>
          <div><dt>Email</dt><dd><a href="mailto:info@iraqhomeexpo.com">info@iraqhomeexpo.com</a><a href="mailto:sales@iraqhomeexpo.com">sales@iraqhomeexpo.com</a></dd></div>
          <div><dt>Location</dt><dd>Baghdad International Fair<br/>Baghdad, Iraq</dd></div>
          <div><dt>Opening hours</dt><dd>11:00 AM – 6:00 PM</dd></div>
        </dl>
      </div>
      <div className="contactFormPanel">
        <span className="sectionEyebrow">Contact us</span>
        <h2>Send us a message.</h2>
        <SmartForm type="contact"/>
      </div>
    </section>
  );
}
