import Image from "next/image";
import Link from "next/link";
import { event, nav } from "@/data/site";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footerInner">
        <div className="footerBrand">
          <div className="footerLogo"><Image src="/assets/iraq-home-expo-logo-header.png" width={1993} height={583} alt="Iraq Home Expo"/></div>
          <p>{event.dates}<br/>{event.venue}<br/>{event.city}</p>
        </div>
        <div className="footerLinks">
          <h3>Quick links</h3>
          {nav.slice(0,4).map(([l,h])=><Link href={h} key={h}>{l}</Link>)}
        </div>
        <div className="footerLinks">
          <h3>Exhibit</h3>
          <Link href="/exhibit">Why Exhibit</Link>
          <Link href="/sectors">Exhibition Sectors</Link>
          <Link href="/register#exhibitor">Book Your Stand</Link>
        </div>
        <div className="footerLinks">
          <h3>Contact us</h3>
          <a href="mailto:info@iraqhomeexpo.com">info@iraqhomeexpo.com</a>
          <a href="mailto:sales@iraqhomeexpo.com">sales@iraqhomeexpo.com</a>
          <a href="tel:+9647824455860">07824455860</a>
          <a href="tel:+9647702550297">07702550297</a>
        </div>
      </div>
      <div className="footerBottom"><span>© 2027 Iraq Home Expo. All rights reserved.</span><div><Link href="/privacy">Privacy Policy</Link><Link href="/terms">Terms of Use</Link></div></div>
    </footer>
  );
}
