"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { nav, sectors } from "@/data/site";
import { IconChevron } from "@/components/Icons";

export default function Header() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [sectorsOpen, setSectorsOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 28);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  const closeMenu = () => {
    setOpen(false);
    setSectorsOpen(false);
  };

  const isActive = (href: string) =>
    href === "/sectors" ? pathname.startsWith("/sectors") : pathname === href;

  return (
    <>
      <header className={`siteHeader ${scrolled ? "isScrolled" : ""}`}>
        <div className="headerInner">
          <Link href="/" className="brandLockup" aria-label="Iraq Home Expo home">
            <Image
              src="/assets/iraq-home-expo-logo-header.png"
              alt="Iraq Home Expo"
              width={1993}
              height={583}
              priority
            />
          </Link>

          <nav className="desktopNav" aria-label="Primary navigation">
            {nav.map(([label, href]) =>
              label === "Sectors" ? (
                <div className="megaWrap" key={href}>
                  <Link className={isActive(href) ? "active" : ""} href={href}>
                    <span>{label}</span>
                    <IconChevron className="navChevron" size={12} />
                  </Link>
                  <div className="megaMenu" role="menu">
                    <div className="megaMenuHead">
                      <div>
                        <small>Exhibition sectors</small>
                        <strong>Explore the complete home industry</strong>
                      </div>
                      <Link href="/sectors">View all sectors <span>→</span></Link>
                    </div>
                    <div className="megaGrid">
                      {sectors.map((s, i) => (
                        <Link key={s.slug} href={`/sectors/${s.slug}`} role="menuitem">
                          <span className="megaNum">{String(i + 1).padStart(2, "0")}</span>
                          <span className="megaTitle">{s.title}</span>
                          <span className="megaArrow">→</span>
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <Link className={isActive(href) ? "active" : ""} key={href} href={href}>
                  {label}
                </Link>
              )
            )}
          </nav>

          <Link className="headerCta" href="/register">
            Register <span aria-hidden="true">→</span>
          </Link>

          <button
            className={`menuButton ${open ? "isOpen" : ""}`}
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen(!open)}
          >
            <span /><span /><span />
          </button>
        </div>
      </header>

      <div className={`mobileMenuOverlay ${open ? "open" : ""}`} aria-hidden={!open}>
        <div className="mobileMenuTop">
          <Link href="/" className="mobileBrand" onClick={closeMenu}>
            <Image src="/assets/iraq-home-expo-logo-header.png" alt="Iraq Home Expo" width={1993} height={583}/>
          </Link>
          <button className="mobileClose" onClick={closeMenu} aria-label="Close menu">×</button>
        </div>
        <nav className="mobileMenu" aria-label="Mobile navigation">
          {nav.map(([label, href]) =>
            label === "Sectors" ? (
              <div className="mobileNavGroup" key={href}>
                <button
                  type="button"
                  className="mobileNavToggle"
                  aria-expanded={sectorsOpen}
                  onClick={() => setSectorsOpen(!sectorsOpen)}
                >
                  <span>{label}</span>
                  <IconChevron className={sectorsOpen ? "rotated" : ""} size={17}/>
                </button>
                <div className={`mobileSubNav ${sectorsOpen ? "open" : ""}`}>
                  <Link onClick={closeMenu} href={href}>All Sectors</Link>
                  {sectors.map((s) => (
                    <Link key={s.slug} onClick={closeMenu} href={`/sectors/${s.slug}`}>
                      {s.title}
                    </Link>
                  ))}
                </div>
              </div>
            ) : (
              <Link onClick={closeMenu} key={href} href={href} className="mobileNavLink">
                {label}
              </Link>
            )
          )}
          <Link onClick={closeMenu} href="/register" className="mobileRegisterCta">
            Register to Visit or Exhibit <span>→</span>
          </Link>
        </nav>
      </div>
    </>
  );
}
