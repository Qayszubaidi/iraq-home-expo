import Image from "next/image";
import Link from "next/link";
export default function PageHero({eyebrow,title,copy,image="/assets/hero-interior.webp",primary="Register",primaryHref="/register",compact=false}:{eyebrow:string,title:string,copy:string,image?:string,primary?:string,primaryHref?:string,compact?:boolean}){return <section className={`pageHero baquetHero ${compact?"compact":""}`}>
  <div className="pageHeroMedia"><Image src={image} fill priority alt="" className="cover"/><div className="shade"/></div>
  <div className="pageHeroContent"><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{copy}</p><Link className="button gold pageHeroCta" href={primaryHref}>{primary}<span>→</span></Link></div>
  <div className="pageHeroAccent" aria-hidden="true"/>
</section>}
