"use client";
import Link from "next/link";
import { useState } from "react";

export default function FloatingRegister() {
  const [open, setOpen] = useState(false);
  return (
    <div className={`floatingDock ${open ? "open" : ""}`}>
      <div className="floatingPanel" aria-hidden={!open}>
        <div className="floatingPanelHead">
          <div>
            <span>Register for Iraq Home Expo</span>
            <small>12–15 May 2027 · Baghdad</small>
          </div>
          <button onClick={() => setOpen(false)} aria-label="Close registration menu">×</button>
        </div>
        <p>Choose how you want to participate.</p>
        <Link onClick={() => setOpen(false)} href="/register#visitor">
          <small>Professional visitors</small>
          <strong>Register to Visit</strong>
          <span>→</span>
        </Link>
        <Link onClick={() => setOpen(false)} href="/register#exhibitor">
          <small>Manufacturers, suppliers &amp; brands</small>
          <strong>Exhibitor Registration</strong>
          <span>→</span>
        </Link>
      </div>
      <button className="floatingRegister" aria-expanded={open} onClick={() => setOpen(!open)}>
        <span className="pulseDot" />
        <span className="floatingText">Register</span>
        <span className="floatingIcon">{open ? "×" : "→"}</span>
      </button>
    </div>
  );
}
