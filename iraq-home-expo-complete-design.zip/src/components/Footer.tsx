import Image from "next/image";
import Link from "next/link";
import { event, nav, sectors } from "@/data/site";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footerPattern" aria-hidden="true" />
      <div className="footerTop">
        <div className="footerBrand">
          <div className="footerLogo">
            <Image src="/assets/iraq-home-expo-logo.png" width={260} height={115} alt="Iraq Home Expo" />
          </div>
          <p className="footerEvent">
            <strong>{event.dates}</strong>
            <span>{event.venue}</span>
            <span>{event.city}</span>
          </p>
          <Link className="button gold footerRegister" href="/register">Register <span>→</span></Link>
        </div>
        <div className="footerNavGroup">
          <h3>Explore</h3>
          {nav.map(([l, h]) => <Link href={h} key={h}>{l}</Link>)}
          <Link href="/register">Register</Link>
        </div>
        <div className="footerNavGroup footerSectors">
          <h3>Sectors</h3>
          {sectors.slice(0, 5).map((s) => <Link href={`/sectors/${s.slug}`} key={s.slug}>{s.title}</Link>)}
          <Link href="/sectors">View all sectors →</Link>
        </div>
        <div className="footerNavGroup">
          <h3>Contact</h3>
          <a href="mailto:info@iraqhomeexpo.com">info@iraqhomeexpo.com</a>
          <a href="mailto:sales@iraqhomeexpo.com">sales@iraqhomeexpo.com</a>
          <a href="tel:+9647824455860">07824455860</a>
          <a href="tel:+9647702550297">07702550297</a>
        </div>
      </div>
      <div className="footerBottom">
        <span>© 2027 Iraq Home Expo</span>
        <div>
          <Link href="/privacy">Privacy</Link>
          <Link href="/terms">Terms</Link>
        </div>
        <span>Organized by Success Steps</span>
      </div>
    </footer>
  );
}
