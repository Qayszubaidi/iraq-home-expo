"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import { nav, sectors } from "@/data/site";

function Chevron({ open = false }: { open?: boolean }) {
  return (
    <svg
      className={`navChevron ${open ? "isOpen" : ""}`}
      viewBox="0 0 12 8"
      width="12"
      height="8"
      aria-hidden="true"
    >
      <path d="M1 1.5 6 6.5 11 1.5" fill="none" stroke="currentColor" strokeWidth="1.4" />
    </svg>
  );
}

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [sectorsOpen, setSectorsOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 42);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const closeMenu = () => {
    setOpen(false);
    setSectorsOpen(false);
  };

  return (
    <>
      <header className={`siteHeader ${scrolled ? "isScrolled" : ""}`}>
        <Link href="/" className="logoPlate" aria-label="Iraq Home Expo home">
          <Image
            src="/assets/iraq-home-expo-logo.png"
            alt="Iraq Home Expo"
            width={250}
            height={110}
            priority
          />
        </Link>

        <nav className="desktopNav" aria-label="Primary navigation">
          {nav.map(([label, href]) =>
            label === "Sectors" ? (
              <div className="megaWrap" key={href}>
                <Link href={href} className="navHasChildren">
                  <span>{label}</span>
                  <Chevron />
                </Link>
                <div className="megaMenu" role="menu">
                  <div className="megaMenuHeader">
                    <div>
                      <span className="megaEyebrow">Exhibition sectors</span>
                      <strong>Explore the complete home industry</strong>
                    </div>
                    <Link href="/sectors" className="megaAllLink">
                      View all sectors <span aria-hidden="true">→</span>
                    </Link>
                  </div>
                  <div className="megaSectorGrid">
                    {sectors.map((s, index) => (
                      <Link key={s.slug} href={`/sectors/${s.slug}`} role="menuitem" className="megaSectorLink">
                        <span className="megaIndex">{String(index + 1).padStart(2, "0")}</span>
                        <span className="megaSectorTitle">{s.title}</span>
                        <span className="megaArrow" aria-hidden="true">→</span>
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <Link key={href} href={href}>
                {label}
              </Link>
            )
          )}
        </nav>

        <Link className="headerCta" href="/register">
          Register <span aria-hidden="true">→</span>
        </Link>

        <button
          className={`menuButton ${open ? "isOpen" : ""}`}
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          onClick={() => setOpen(!open)}
        >
          <span />
          <span />
          <span />
        </button>
      </header>

      <div className={`mobileMenuOverlay ${open ? "open" : ""}`} aria-hidden={!open}>
        <nav className="mobileMenu" aria-label="Mobile navigation">
          <div className="mobileMenuTop">
            <span>Explore Iraq Home Expo</span>
            <small>12–15 May 2027 · Baghdad</small>
          </div>
          {nav.map(([label, href]) =>
            label === "Sectors" ? (
              <div className="mobileNavGroup" key={href}>
                <div className="mobileNavParent">
                  <Link onClick={closeMenu} href={href}>Sectors</Link>
                  <button
                    type="button"
                    className="mobileSubmenuButton"
                    aria-label="Toggle sectors submenu"
                    aria-expanded={sectorsOpen}
                    onClick={() => setSectorsOpen(!sectorsOpen)}
                  >
                    <Chevron open={sectorsOpen} />
                  </button>
                </div>
                <div className={`mobileSubNav ${sectorsOpen ? "isOpen" : ""}`}>
                  {sectors.map((s, index) => (
                    <Link key={s.slug} onClick={closeMenu} href={`/sectors/${s.slug}`}>
                      <span>{String(index + 1).padStart(2, "0")}</span>
                      {s.title}
                    </Link>
                  ))}
                </div>
              </div>
            ) : (
              <Link onClick={closeMenu} key={href} href={href} className="mobileNavLink">
                {label}
              </Link>
            )
          )}
          <Link onClick={closeMenu} href="/register" className="mobileRegisterCta">
            <span>Registration</span>
            <strong>Visit or Exhibit</strong>
            <span aria-hidden="true">→</span>
          </Link>
        </nav>
      </div>
    </>
  );
}
